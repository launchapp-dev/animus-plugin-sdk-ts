// Newline-delimited JSON-RPC 2.0 transport over a Node Readable/Writable pair
// (stdin/stdout by default).
//
// Mirrors the Rust runtime in `crates/animus-plugin-runtime/src/lib.rs`:
//   - one JSON-RPC frame per line of stdin
//   - replies + server-streaming notifications are newline-terminated JSON
//     written to stdout
//   - parse errors on a single line are logged-and-skipped (do not kill the
//     read loop)
//   - empty/whitespace-only lines are ignored
//
// Stdout is reserved for protocol frames; SDK diagnostics MUST go to stderr.

import type { Readable, Writable } from 'node:stream';
import { stdin as nodeStdin, stdout as nodeStdout } from 'node:process';
import { StringDecoder } from 'node:string_decoder';

import type { RpcId, RpcNotification, RpcRequest, RpcResponse } from './types/index.js';

/** A handler invoked for every parsed inbound JSON-RPC frame.
 *  Return `undefined` for notifications (no response expected). */
export type FrameHandler = (frame: RpcRequest) => Promise<RpcResponse | undefined> | RpcResponse | undefined;

export interface WireOptions {
  /** Readable stream to consume newline-delimited JSON-RPC frames from. Defaults to process.stdin. */
  input?: Readable;
  /** Writable stream to write newline-terminated JSON-RPC frames to. Defaults to process.stdout. */
  output?: Writable;
  /** Logger for invalid frames / errors. Defaults to `console.error`. */
  logger?: (msg: string, err?: unknown) => void;
  /**
   * Maximum number of request handlers dispatched concurrently. Defaults to
   * `1` — strictly serial, responding in arrival order, byte-identical to the
   * historical loop. Raise it for a plugin whose handlers are independent
   * request/response (e.g. the consolidated Postgres BaaS plugin serving many
   * roles on one process): serial dispatch there head-of-line-blocks an
   * unrelated role's request behind whatever is currently in flight. Responses
   * may then complete out of arrival order — safe, because the Rust plugin host
   * correlates replies by `id`. Stdout writes stay serialized via `WriteQueue`,
   * so frames never interleave regardless of this value.
   */
  maxConcurrency?: number;
}

export interface Wire {
  /** Send a JSON-RPC response. */
  sendResponse(response: RpcResponse): Promise<void>;
  /** Send a JSON-RPC server-streaming notification (no `id`). */
  sendNotification(notification: RpcNotification): Promise<void>;
  /** Convenience: build + send a notification from method/params. */
  notify(method: string, params?: unknown): Promise<void>;
  /**
   * Register out-of-band background work (e.g. a long-running provider
   * `agent/run` that streams notifications and sends its own final response
   * later). `run()` will not resolve on EOF until all tracked work settles, so
   * a detached run's final response is still flushed before shutdown. Rejections
   * are swallowed (they are reported by the owning dispatcher); tracking only
   * gates loop completion, it never poisons it.
   */
  track(work: Promise<unknown>): void;
  /** Begin consuming the input stream. Resolves when the stream closes (EOF). */
  run(handler: FrameHandler): Promise<void>;
}

const defaultLogger = (msg: string, err?: unknown): void => {
  if (err !== undefined) {
    process.stderr.write(`[animus-plugin-sdk] ${msg}: ${String(err)}\n`);
  } else {
    process.stderr.write(`[animus-plugin-sdk] ${msg}\n`);
  }
};

/**
 * Encode a single JSON-RPC frame as a UTF-8 newline-terminated string.
 * Exposed for tests; production code should go through `Wire.sendResponse` /
 * `Wire.sendNotification`.
 */
export function encodeFrame(frame: RpcResponse | RpcNotification | RpcRequest): string {
  return `${JSON.stringify(frame)}\n`;
}

/**
 * Parse one trimmed line into an `RpcRequest`. Throws on invalid JSON or
 * structurally invalid JSON-RPC (missing `jsonrpc: "2.0"` or `method`).
 */
export function parseFrame(line: string): RpcRequest {
  const value = JSON.parse(line) as unknown;
  if (typeof value !== 'object' || value === null) {
    throw new Error('frame is not a JSON object');
  }
  const obj = value as Record<string, unknown>;
  if (obj.jsonrpc !== '2.0') {
    throw new Error(`unsupported jsonrpc version: ${String(obj.jsonrpc)}`);
  }
  if (typeof obj.method !== 'string' || obj.method.length === 0) {
    throw new Error('frame missing string `method`');
  }
  const frame: RpcRequest = {
    jsonrpc: '2.0',
    method: obj.method,
  };
  if ('id' in obj) {
    frame.id = obj.id as RpcId;
  }
  if ('params' in obj) {
    frame.params = obj.params;
  }
  return frame;
}

class WriteQueue {
  private chain: Promise<void> = Promise.resolve();
  constructor(private readonly output: Writable) {}

  enqueue(payload: string): Promise<void> {
    const next = this.chain.then(
      () =>
        new Promise<void>((resolve, reject) => {
          const ok = this.output.write(payload, (err) => {
            if (err) reject(err);
            else resolve();
          });
          if (!ok) {
            this.output.once('drain', () => {
              // write callback still fires; nothing to do here.
            });
          }
        }),
    );
    // Swallow rejections in the chain so a single write failure doesn't poison
    // the queue; the original caller still sees the rejection.
    this.chain = next.catch(() => undefined);
    return next;
  }
}

/**
 * Create a `Wire` bound to the given (or default stdin/stdout) streams.
 *
 * Reads are line-buffered: a frame ends at the next `\n`. Frames that fail to
 * parse are logged via `options.logger` and skipped, matching the Rust
 * runtime's "tracing::warn + continue" behavior.
 */
export function createWire(options: WireOptions = {}): Wire {
  const input = options.input ?? nodeStdin;
  const output = options.output ?? nodeStdout;
  const log = options.logger ?? defaultLogger;
  const queue = new WriteQueue(output);

  const sendResponse: Wire['sendResponse'] = (response) => queue.enqueue(encodeFrame(response));
  const sendNotification: Wire['sendNotification'] = (notification) =>
    queue.enqueue(encodeFrame(notification));
  const notify: Wire['notify'] = (method, params) => {
    const frame: RpcNotification = params === undefined
      ? { jsonrpc: '2.0', method }
      : { jsonrpc: '2.0', method, params };
    return sendNotification(frame);
  };

  // Out-of-band background work (detached provider runs). `finish()` drains
  // this set so a run started just before EOF still flushes its final response.
  const pending = new Set<Promise<unknown>>();
  const track: Wire['track'] = (work) => {
    const wrapped = Promise.resolve(work).catch(() => undefined);
    pending.add(wrapped);
    void wrapped.finally(() => pending.delete(wrapped));
  };

  const run: Wire['run'] = (handler) =>
    new Promise<void>((resolve, reject) => {
      let buffer = '';
      let closed = false;
      // `StringDecoder` buffers partial multi-byte UTF-8 sequences across
      // chunk boundaries — `chunk.toString('utf8')` would replace a split
      // codepoint with U+FFFD and corrupt valid JSON containing non-ASCII
      // subject titles.
      const decoder = new StringDecoder('utf8');
      // Bounded-concurrent request dispatch: up to `maxConcurrency` handlers run
      // at once, the rest wait FIFO in `lineQueue`. At the default of 1 this is
      // strictly serial (responses in arrival order), byte-identical to the
      // historical single-chain loop. Plugins can still kick off background work
      // inside a handler and emit streaming notifications via
      // `notify`/`sendNotification`.
      const maxConcurrency = Math.max(1, Math.floor(options.maxConcurrency ?? 1));
      const lineQueue: string[] = [];
      const inFlight = new Set<Promise<void>>();

      const handleOne = async (line: string): Promise<void> => {
        const trimmed = line.trim();
        if (trimmed.length === 0) return;
        let frame: RpcRequest;
        try {
          frame = parseFrame(trimmed);
        } catch (err) {
          log('invalid JSON-RPC frame', err);
          return;
        }
        try {
          const response = await handler(frame);
          if (response !== undefined) {
            await sendResponse(response);
          }
        } catch (err) {
          log(`handler error for method '${frame.method}'`, err);
        }
      };

      // Start as many queued handlers as the concurrency budget allows. Each
      // handler, on settling, frees its slot and re-pumps so the queue keeps
      // draining. handleOne never rejects (it catches internally), so the
      // in-flight promises are always resolve-only.
      const pump = (): void => {
        while (inFlight.size < maxConcurrency && lineQueue.length > 0) {
          const line = lineQueue.shift() as string;
          const work = handleOne(line);
          inFlight.add(work);
          void work.finally(() => {
            inFlight.delete(work);
            pump();
          });
        }
      };

      const enqueue = (line: string): void => {
        lineQueue.push(line);
        pump();
      };

      const onData = (chunk: Buffer | string): void => {
        buffer += typeof chunk === 'string' ? chunk : decoder.write(chunk);
        let newlineIdx = buffer.indexOf('\n');
        while (newlineIdx !== -1) {
          const line = buffer.slice(0, newlineIdx);
          buffer = buffer.slice(newlineIdx + 1);
          enqueue(line);
          newlineIdx = buffer.indexOf('\n');
        }
      };

      const finish = async (): Promise<void> => {
        if (closed) return;
        closed = true;
        // Flush any bytes the decoder held while waiting for the rest of a
        // multi-byte sequence; emit them as part of the final line.
        buffer += decoder.end();
        if (buffer.length > 0) {
          enqueue(buffer);
          buffer = '';
        }
        // Drain the queued + in-flight request handlers (which may settle out
        // of order at maxConcurrency > 1) before resolving.
        while (lineQueue.length > 0 || inFlight.size > 0) {
          pump();
          if (inFlight.size > 0) {
            await Promise.race([...inFlight]);
          }
        }
        // Then drain any out-of-band background work (detached provider runs)
        // so their final responses are flushed before the loop resolves. A
        // settling run may register follow-on work, so loop until quiescent.
        while (pending.size > 0) {
          await Promise.all([...pending]);
        }
        resolve();
      };

      const onError = (err: Error): void => {
        if (closed) return;
        closed = true;
        reject(err);
      };

      input.on('data', onData);
      input.once('end', () => {
        void finish();
      });
      input.once('close', () => {
        void finish();
      });
      input.once('error', onError);
    });

  return { sendResponse, sendNotification, notify, track, run };
}

/** Build an `ok` response for the given request id. */
export function okResponse(id: RpcId | undefined, result: unknown): RpcResponse {
  return { jsonrpc: '2.0', id: id ?? null, result };
}

/** Build an `error` response for the given request id. */
export function errorResponse(id: RpcId | undefined, code: number, message: string, data?: unknown): RpcResponse {
  const error = data === undefined ? { code, message } : { code, message, data };
  return { jsonrpc: '2.0', id: id ?? null, error };
}
